import { Component } from '@angular/core';

@Component({
  selector: 'app-form-one',
  templateUrl: './form-one.component.html',
  styleUrls: ['./form-one.component.css'] // Use styleUrls for specifying stylesheets
})
export class FormOneComponent {
  name: string = ''; // Declare and initialize 'name' property
  serviceId: string = ''; // Declare and initialize 'serviceId' property
  manager: string = ''; // Declare and initialize 'manager' property
date: any;

  updateTable(): void { // Define 'updateTable' method
    // Implementation of updateTable method goes here
  }
}
